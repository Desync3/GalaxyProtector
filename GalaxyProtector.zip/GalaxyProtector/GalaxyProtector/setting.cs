﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public static class setting
{
    public static bool method = false;
    public static bool prop = false;
    public static bool eventb = false;
    public static bool field = false;
    public static bool names = false;
}

